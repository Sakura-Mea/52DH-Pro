CREATE TABLE IF NOT EXISTS `pre_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '网站名称',
  `img` varchar(500) NOT NULL COMMENT '网站图标',
  `catename` varchar(255) NOT NULL COMMENT '网站分类',
  `url` varchar(500) NOT NULL COMMENT '网站URL',
  `keywords` varchar(255) NOT NULL COMMENT '网站关键词',
  `introduce` text NOT NULL COMMENT '网站介绍',
  `reject` int(2) NOT NULL DEFAULT '0' COMMENT '拒绝收录：0待审核1拒绝',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `pre_apply` (`id`, `name`, `img`, `catename`, `url`, `keywords`, `introduce`, `reject`) VALUES
(1, 'hao123导航', 'https://www.hao123.com/favicon.ico', '目录导航', 'https://www.hao123.com', '上网导航,网址大全,网址导航,hao123上网导航,hao123网址,hao123导航,hao123网址大全,hao123活动,抽奖活动', 'hao123是汇集全网优质网址及资源的中文上网导航。及时收录影视、音乐、小说、游戏等分类的网址和内容，让您的网络生活更简单精彩。上网，从hao123开始。', 1),
(2, '好看视频', 'https://hk.bdstatic.com/app/favicon.ico', '影音娱乐', 'https://haokan.baidu.com', '好看视频APP,短视频,小视频,高清视频,vlog,vlog拍摄器,影视视频,音乐视频,搞笑视频,直播,娱乐视频,动漫视频,明星视频,明星视频,亲子视频,宠物视频', '好看视频是百度短视频旗舰品牌，拥有超百万的短视频创作者。全面覆盖知识、美食、生活、健康、文化、游戏、影视等海量视频，致力于为用户提供优质的视频内容与观看体验，让用户轻松有收获。', 0);</explode>

CREATE TABLE IF NOT EXISTS `pre_config` (
  `k` varchar(255) NOT NULL,
  `v` text,
  PRIMARY KEY (`k`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `pre_config` (`k`, `v`) VALUES
('admin_user', 'admin'),
('admin_pwd', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92'),
('qq', '3288637559'),
('email', 'admin@qq.com'),
('name', '我爱导航'),
('title', '我爱导航'),
('keywords', '我爱导航,网址导航,网址大全,工具导航推荐,上网导航推荐,网站导航推荐,导航网站,最好的导航网站,导航网站,导航网站推荐,导航网站分类,网址大全分,导航系统,网站导航,网址导航系统'),
('description', '我爱导航系统是一个专业收录优质网站的网址导航平台，提供简洁高效的网络入口。免费提交收录，发现实用工具、设计资源、程序员必备站，打造您的专属上网主页'),
('icp', '沪ICP备20016252号'),
('script_header', '<!-- script_header -->'),
('script_footer', '<!-- script_footer -->'),
('info', '免责声明：我爱导航系统所列站点收集于全球互联网，内容与本站无关'),
('shots_api', '//www.example.com/'),
('ico_api', '//www.example.com/get.php?url='),
('tdk_api', '//www.example.com/?url=');</explode>

CREATE TABLE IF NOT EXISTS `pre_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '站点名称',
  `url` varchar(500) NOT NULL COMMENT '站点URL',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `pre_link` (`id`, `name`, `url`) VALUES
(1, '山海数据', 'https://www.munsea.com'),
(2, '梦之付', 'https://xpay.233m.com'),
(3, '苏酷伊', 'https://www.sukuy.com');</explode>

CREATE TABLE IF NOT EXISTS `pre_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL DEFAULT '1' COMMENT '数字越小排名越前',
  `name` varchar(255) NOT NULL COMMENT '站点名称',
  `img` varchar(500) NOT NULL COMMENT '站点图标',
  `catename` varchar(255) NOT NULL COMMENT '站点分类',
  `url` varchar(500) NOT NULL COMMENT '站点链接',
  `alias` varchar(255) DEFAULT NULL COMMENT '站点链接别名[a-zA-Z]+',
  `keywords` varchar(255) NOT NULL COMMENT '关键词',
  `introduce` text NOT NULL COMMENT '站点描述',
  `time` varchar(50) NOT NULL COMMENT '收录日期',
  `hits_total` int(20) NOT NULL DEFAULT '0' COMMENT '总浏览数',
  `hits_month` int(20) NOT NULL DEFAULT '0' COMMENT '月浏览数',
  `hits_day` int(20) NOT NULL DEFAULT '0' COMMENT '日浏览数',
  `date` varchar(50) NOT NULL COMMENT '年-月-日',
  `datem` varchar(50) NOT NULL COMMENT '年-月',
  `like` int(20) NOT NULL DEFAULT '0' COMMENT '点赞数',
  `tui` int(2) NOT NULL DEFAULT '0' COMMENT '是否推荐：1是0否',
  `star` int(2) NOT NULL DEFAULT '2' COMMENT '站点星级：12345个等级',
  `drtime` timestamp NULL DEFAULT NULL COMMENT '站点回访时间',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

DELETE FROM `pre_site` WHERE `id` IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012, 1013);</explode>

CREATE TABLE IF NOT EXISTS `pre_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nid` int(11) NOT NULL COMMENT '排序号:数字越小排名越前',
  `icon` varchar(255) NOT NULL COMMENT '图标',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `url` varchar(500) NOT NULL COMMENT 'URL',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `pre_nav` (`id`, `nid`, `icon`, `name`, `url`) VALUES
(1, 1, 'fa-home', '导航首页', './'),
(2, 2, 'fa-flag', '排行榜单', 'ranking.html'),
(3, 3, 'fa-plus-square', '申请收录', 'apply.html'),
(4, 4, 'fa-book', '文章信息', 'article.html'),
(5, 5, 'fa-info-circle', '关于本站', 'about.html');</explode>

CREATE TABLE IF NOT EXISTS `pre_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL COMMENT '通知内容',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `pre_notice` (`id`, `content`) VALUES
(1, '欢迎使用我爱导肮（52DH Pro）系统');</explode>

CREATE TABLE IF NOT EXISTS `pre_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL COMMENT '排序号:数字越小排名越前',
  `icon` varchar(255) NOT NULL COMMENT '分类图标:Font Awesome图标',
  `catename` varchar(255) NOT NULL COMMENT '分类名称',
  `alias` varchar(255) DEFAULT NULL COMMENT '分类别名:[a-zA-Z]+',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `pre_category` (`id`, `sid`, `icon`, `catename`) VALUES
(1,1,'fa-paper-plane','目录导航'),
(2,2,'fa-file-text','博客社区'),
(3,3,'fa-cubes','社会生活'),
(4,4,'fa-youtube-play','影音娱乐'),
(5,5,'fa-cloud','IDC网站'),
(6,6,'fa-line-chart ','行业机构'),
(7,7,'fa-graduation-cap','教育学习'),
(8,8,'fa-jpy','投资理财'),
(9,9,'fa-wrench','辅助工具'),
(11,10,'fa fa-keyboard-o','软件IT'),
(12,11,'fa-shopping-cart','购物商城'),
(13,12,'fa fa-download','资源下载');</explode>

CREATE TABLE IF NOT EXISTS `pre_article_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL COMMENT '排序号:数字越小排名越前',
  `icon` varchar(255) NOT NULL COMMENT '分类图标:Font Awesome图标',
  `catename` varchar(255) NOT NULL COMMENT '分类名称',
  `alias` varchar(255) DEFAULT NULL COMMENT '分类别名:[a-zA-Z]+',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `pre_article_category` (`id`, `sid`, `icon`, `catename`) VALUES
(1, 1, 'fa fa-folder-open', '资源分享'),
(2, 2, 'fa fa-gift', '羊毛线报'),
(3, 3, 'fa fa-floppy-o', '网站优化'),
(4, 4, 'fa-fast-forward', '其他资讯');</explode>

CREATE TABLE IF NOT EXISTS `pre_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '文章标题',
  `catename` varchar(255) NOT NULL COMMENT '文章分类',
  `introduce` text NOT NULL COMMENT '文章内容',
  `hits_total` int(20) NOT NULL DEFAULT '0' COMMENT '总浏览量',
  `tui` int(2) NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `time` varchar(50) NOT NULL COMMENT '创建时间',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `pre_article` (`id`, `name`, `catename`, `introduce`, `hits_total`, `tui`, `time`) VALUES
(1, '文章标题', '资源分享', '<p>文章详情信息</p>', 66, 1, '2021-10-25');</explode>

CREATE TABLE IF NOT EXISTS `pre_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL COMMENT '站点ID',
  `like_ip` varchar(255) NOT NULL COMMENT '点赞者IP',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>
