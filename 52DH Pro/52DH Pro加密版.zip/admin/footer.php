
</div><!-- col-sm-9 col-md-9 col-lg-10 end -->
    </div><!-- row page-wrapper end -->

</div><!-- container-fluid end -->

<script src="<?php echo $site_cdnpublic; ?>jquery/1.12.4/jquery.min.js"></script>
<script src="<?php echo $site_cdnpublic; ?>twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo $site_cdnpublic; ?>layer/3.1.1/layer.js"></script>
<!-- <script src="../assets/js/common.js"></script> -->
<script src="../assets/js/admin.js"></script>
<script src="<?php echo $site_cdnpublic; ?>js/anti_copy.js"></script>
