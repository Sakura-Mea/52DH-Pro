// 禁止右键菜单
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
    return false;
});

// 禁止F12和Ctrl+Shift+I等开发者工具快捷键
document.addEventListener('keydown', function(e) {
    // F12键
    if (e.key === 'F12') {
        e.preventDefault();
    }
    // Ctrl+Shift+I
    if (e.ctrlKey && e.shiftKey && e.key === 'I') {
        e.preventDefault();
    }
    // Ctrl+U (查看源码)
    if (e.ctrlKey && e.key === 'u') {
        e.preventDefault();
    }
    // Ctrl+Shift+C
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
        e.preventDefault();
    }
});

// 禁止选中文字
document.addEventListener('selectstart', function(e) {
    e.preventDefault();
    return false;
});

// 禁止复制
document.addEventListener('copy', function(e) {
    e.preventDefault();
    return false;
});

// 禁止剪切
document.addEventListener('cut', function(e) {
    e.preventDefault();
    return false;
});