<?php
/* 数据库配置 */
$dbconfig = array(
    'host'   => '127.0.0.1', // 数据库服务器
    'port'   => 3306, // 数据库端口
    'user'   => 'nav_sukuy_com', // 数据库用户名
    'pwd'    => 'ZNGA5CDcwN9zrPHk', // 数据库密码
    'dbname' => 'nav_sukuy_com', // 数据库名
    'prefix' => 'pre' // 数据库表前缀
);