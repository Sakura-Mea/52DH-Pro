<?php

// ini_set('display_errors', 'On');
// error_reporting(E_ALL);
// error_reporting(-1);
error_reporting(0);
define('IN_CRONLITE', true);
define('VERSION', '1002');
define('APP_VERSION', '1.0.0');
define('SYSTEM_ROOT', dirname(__FILE__));
define('ROOT', dirname(SYSTEM_ROOT));
// define('CC_Defender', 1);
@header('Content-Type: text/html; charset=UTF-8');
date_default_timezone_set("PRC");
$date = date("Y-m-d H:i:s");
session_start();

// 拟态风格核心CSS（全局复用）
$neumo_css = '
<style>
/* 拟态基础样式 */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}
body {
    background-color: #e0e5ec;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}
/* 拟态容器（凸起效果） */
.neumo-container {
    background-color: #e0e5ec;
    padding: 35px;
    border-radius: 16px;
    box-shadow: 8px 8px 16px #d1d9e6, 
                -8px -8px 16px #ffffff;
    max-width: 650px;
    width: 100%;
}
/* 拟态标题 */
.neumo-title {
    color: #4a6fa5;
    font-size: 24px;
    font-weight: 600;
    margin-bottom: 25px;
    text-align: center;
    letter-spacing: 0.5px;
}
/* 拟态列表 */
.neumo-list {
    list-style-position: inside;
    margin: 15px 0;
    line-height: 1.8;
}
.neumo-list li {
    color: #5c7ba0;
    font-size: 16px;
    margin: 12px 0;
}
/* 拟态链接（凹陷交互） */
.neumo-link {
    display: inline-block;
    margin: 10px 0;
    padding: 12px 28px;
    background-color: #e0e5ec;
    color: #4a6fa5;
    text-decoration: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 500;
    box-shadow: inset 4px 4px 8px #d1d9e6, 
                inset -4px -4px 8px #ffffff;
    transition: all 0.3s ease;
}
.neumo-link:hover {
    box-shadow: 4px 4px 8px #d1d9e6, 
                -4px -4px 8px #ffffff;
    transform: translateY(-2px);
}
/* 拟态说明文本 */
.neumo-desc {
    color: #6d8aad;
    font-size: 15px;
    line-height: 1.7;
    margin: 18px 0;
    text-align: left;
}
/* 403页面特殊样式 */
.neumo-403 {
    text-align: center;
}
.neumo-403-code {
    font-size: 72px;
    font-weight: 700;
    color: #4a6fa5;
    margin-bottom: 15px;
}
/* 版权信息样式 */
.neumo-copyright {
    color: #8a9cb8;
    font-size: 14px;
    text-align: center;
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #d1d9e6;
}
</style>
';

// 自定义拟态风格提示函数（替换原sysmsg逻辑的UI输出）
function neumo_sysmsg($content, $title = '系统提示', $is_simple = 0) {
    global $neumo_css, $site_url;
    $html = '<!DOCTYPE html><html lang="zh-CN">';
    $html .= '<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">';
    $html .= '<title>' . $title . '</title>' . $neumo_css . '</head>';
    $html .= '<body><div class="neumo-container">';
    $html .= '<h2 class="neumo-title">' . $title . '</h2>';
    $html .= '<div class="neumo-desc">' . $content . '</div>';
    // 非简单模式添加返回首页链接
    if (!$is_simple) {
        $html .= '<a href="' . $site_url . '" class="neumo-link">返回首页</a>';
    }
    // 添加版权信息
    $html .= '<div class="neumo-copyright">© ' . date('Y') . ' 52DH Pro All Rights Reserved. Powered By CROGRAM</div>';
    $html .= '</div></body></html>';
    echo $html;
    exit;
}

// if (CC_Defender != 0) {
//     include_once SYSTEM_ROOT . '/security.php';
// }

include_once(SYSTEM_ROOT . '/functions.php');
$scriptpath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
$site_http = (is_https() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
$site_path = substr($scriptpath, 0, strrpos($scriptpath, '/'));

if (file_exists(ROOT . '/install/index.php') && !file_exists(ROOT . '/install/install.lock')) {
    // 拟态风格：安装保护提示
    $content = '
    <h3 class="neumo-title" style="font-size:20px;margin-bottom:15px;">为了您的站点安全，系统暂时无法工作</h3>
    <ul class="neumo-list">
        <li>如果您尚未安装本程序，请 <a href="' . $site_http . '/install/" class="neumo-link" style="padding:8px 18px;font-size:14px;">前往安装</a></li>
        <li>如果您已完成安装，请删除 <code style="background:#f1f5f9;padding:2px 8px;border-radius:4px;">install</code> 文件夹，或在 <code style="background:#f1f5f9;padding:2px 8px;border-radius:4px;">/install</code> 下创建 <code style="background:#f1f5f9;padding:2px 8px;border-radius:4px;">install.lock</code> 文件</li>
    </ul>
    <div class="neumo-desc">
        <h4 style="color:#4a6fa5;margin:20px 0 10px;">为什么需要 install.lock 文件？</h4>
        它是安装保护锁，若检测不到该文件，系统会判定为未安装状态，任何人都可能重装网站，导致数据丢失。
    </div>
    ';
    neumo_sysmsg($content, '安装保护提示');
}

if (!file_exists(ROOT . '/config.php')) {
    // 拟态风格：配置文件丢失提示
    $content = '<h3 class="neumo-title" style="font-size:20px;">系统配置文件 config.php 丢失</h3>';
    $content .= '<a href="' . $site_http . '/install/" class="neumo-link">点击此处运行安装程序</a>';
    neumo_sysmsg($content, '配置错误', 1);
}

// 配置文件
require ROOT . '/config.php';
if (isset($app_config['subpath']) && !empty($app_config['subpath'])) {
    $site_path = str_replace($app_config['subpath'], '', $site_path);
}

$site_url = $site_http . $site_path;

if (!isset($dbconfig) || !$dbconfig['user'] || !$dbconfig['pwd'] || !$dbconfig['dbname']) {
    // 拟态风格：配置文件异常提示
    $content = '<h3 class="neumo-title" style="font-size:20px;">系统配置文件 config.php 异常</h3>';
    $content .= '<a href="' . $site_http . '/install/" class="neumo-link">点击此处运行安装程序</a>';
    neumo_sysmsg($content, '配置错误', 1);
}

include_once(SYSTEM_ROOT . '/autoloader.php');
Autoloader::register();
$DB = new \lib\PdoHelper($dbconfig);
if ($DB->query("select * from pre_config where 1") == FALSE) {
    // 拟态风格：未安装提示
    $html = '<!DOCTYPE html><html lang="zh-CN">';
    $html .= '<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">';
    $html .= '<title>未安装提示</title>' . $neumo_css . '</head>';
    $html .= '<body><div class="neumo-container neumo-403">';
    $html .= '<h2 class="neumo-title">检测到未安装状态</h2>';
    $html .= '<a href="' . $site_http . '/install/" class="neumo-link">点此开始安装</a>';
    // 添加版权信息
    $html .= '<div class="neumo-copyright">© ' . date('Y') . 'copyright 52DH Pro 版权所有</div>';
    $html .= '</div></body></html>';
    echo $html;
    exit();
}

$conf = getAllSetting();
define('SYS_KEY', $conf['sys_key']);

$site_cdnpublic = $site_http . '/assets/';
$password_hash = '!@#%!s!0';
$admin_islogin = 0;

if (isset($_COOKIE["admin_token"])) {
    $token = authcode(daddslashes($_COOKIE['admin_token']), 'DECODE', SYS_KEY);
    list($user, $sid) = explode("\t", $token);
    $session = md5($conf['admin_user'] . $conf['admin_pwd'] . $password_hash);
    if ($session == $sid) {
        $admin_islogin = 1;
    }
}

if (defined('IN_ADMIN')) return;

if (isset($conf['blackip'])) {
    $denyip = explode('|', $conf['blackip']);
    $clientip = $_SERVER['REMOTE_ADDR'];
    if (in_array($clientip, $denyip) && !$admin_islogin) {
        // 拟态风格：403禁止访问页面
        $html = '<!DOCTYPE html><html lang="zh-CN">';
        $html .= '<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">';
        $html .= '<title>403 禁止访问</title>' . $neumo_css . '</head>';
        $html .= '<body><div class="neumo-container neumo-403">';
        $html .= '<div class="neumo-403-code">403</div>';
        $html .= '<h2 class="neumo-title">禁止访问</h2>';
        $html .= '<div class="neumo-desc">您的IP地址已被列入黑名单，无法访问本站</div>';
        $html .= '<a href="javascript:history.back()" class="neumo-link">返回上一页</a>';
        // 添加版权信息
        $html .= '<div class="neumo-copyright">© ' . date('Y') . ' copyright 52DH Pro 版权所有</div>';
        $html .= '</div></body></html>';
        header("HTTP/1.1 403 Forbidden");
        echo $html;
        exit;
    }
}

$user_islogin = 0;
if (isset($_COOKIE["user_token"])) {
    $token = authcode(daddslashes($_COOKIE['user_token']), 'DECODE', SYS_KEY);
    if ($token) {
        list($uid, $sid, $expiretime) = explode("\t", $token);
        if ($userrow = $DB->getRow("SELECT * FROM pre_user WHERE uid='" . intval($uid) . "' LIMIT 1")) {
            $session = md5($userrow['type'] . $userrow['openid'] . $password_hash);
            if ($session === $sid && $expiretime > time()) {
                if ($userrow['enable'] == 1) {
                    $user_islogin = 1;
                } else {
                    $_SESSION['user_block'] = true;
                }
            }
        }
    }
}